package com.example.automobile;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AutomobileApplicationTests {

	@Test
	void contextLoads() {
	}

}
